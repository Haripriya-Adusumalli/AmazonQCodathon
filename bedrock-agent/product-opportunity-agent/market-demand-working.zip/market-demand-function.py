import json

def lambda_handler(event, context):
    """Simple market demand analysis for Bedrock agent"""
    
    try:
        # Extract query from event
        query = "product"
        if 'inputText' in event:
            query = event['inputText']
        elif 'query' in event:
            query = event['query']
        
        # Simple demand analysis
        demand_score = 75.0
        current_interest = 80.0
        momentum = 1.25
        
        result = {
            "demand_score": demand_score,
            "current_interest": current_interest,
            "momentum": momentum,
            "trending_topics": [f"{query} reviews", f"best {query}", f"{query} price"],
            "news_volume": 45,
            "sentiment": "positive"
        }
        
        # Return simple response
        return {
            'statusCode': 200,
            'body': json.dumps(result)
        }
        
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }